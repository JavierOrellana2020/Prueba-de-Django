from django.apps import AppConfig


class AppkawaiiConfig(AppConfig):
    name = 'appkawaii'
